// JavaScript логика «Гулмира цветы»

// Секретные данные для входа
const SECRET_ADMIN_USER = "admin";
const SECRET_ADMIN_PASS = "Gulmira_Flowers#2026!";

const DEFAULT_PRODUCTS = [
  {
    id: 1,
    title: "Праздничная Голубая Ель в горшке",
    category: "Ёлка",
    price: 25000,
    image: "https://images.unsplash.com/photo-1543257580-7269da773bf5?auto=format&fit=crop&w=600&q=80",
    description: "Натуральная живая голубая ель в кадке, пышная крона в полный рост."
  },
  {
    id: 2,
    title: "Канадская Компактная Сосна",
    category: "Ёлка",
    price: 32000,
    image: "https://images.unsplash.com/photo-1512428813834-c702c7702b78?auto=format&fit=crop&w=600&q=80",
    description: "Пышная густая хвоя и стойкий свежий лесной аромат."
  },
  {
    id: 3,
    title: "Королевская Орхидея Фаленопсис",
    category: "Декоративные цветы",
    price: 8500,
    image: "https://images.unsplash.com/photo-1525310072745-f49212b5ac6d?auto=format&fit=crop&w=600&q=80",
    description: "Роскошные бутоны, продолжительное цветение в полный рост."
  },
  {
    id: 4,
    title: "Антуриум Красный (Мужское счастье)",
    category: "Декоративные цветы",
    price: 7200,
    image: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=600&q=80",
    description: "Яркие глянцевые соцветия насыщенного алого оттенка."
  },
  {
    id: 5,
    title: "Кустовая Садовая Роза (Плетистая)",
    category: "Уличные цветы",
    price: 4500,
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80",
    description: "Морозостойкий сорт для уличных клумб и двора."
  },
  {
    id: 6,
    title: "Петуния Каскадная в кашпо",
    category: "Уличные цветы",
    price: 3800,
    image: "https://images.unsplash.com/photo-1597848212624-a19eb35e2651?auto=format&fit=crop&w=600&q=80",
    description: "Пышная цветочная шапка для украшения веранды и сада."
  },
  {
    id: 7,
    title: "Комплексное Удобрение «Пышный Цвет» (1 л)",
    category: "Удобрение",
    price: 2600,
    image: "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=600&q=80",
    description: "NPK комплекс для бутонизации и укрепления корней."
  },
  {
    id: 8,
    title: "Органический Стимулятор для Роз и Хвойных",
    category: "Удобрение",
    price: 3100,
    image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?auto=format&fit=crop&w=600&q=80",
    description: "Защита от пожелтения хвои и быстрое укоренение."
  }
];

let products = [];
let cart = [];
let isAdminLoggedIn = false;
let uploadedImageDataUrl = "";

document.addEventListener("DOMContentLoaded", () => {
  loadProducts();
  loadCart();
  renderAllViews();
  checkHashRoute();
});

window.addEventListener("hashchange", checkHashRoute);

function checkHashRoute() {
  const hash = window.location.hash.replace("#", "") || "home";
  navigateTo(hash);
}

function navigateTo(pageId) {
  const sections = document.querySelectorAll(".page-section");
  const navLinks = document.querySelectorAll(".nav-link");

  let targetSection = document.getElementById("page-" + pageId);
  if (!targetSection) {
    pageId = "home";
    targetSection = document.getElementById("page-home");
  }

  sections.forEach(s => s.classList.remove("active"));
  targetSection.classList.add("active");

  navLinks.forEach(link => {
    if (link.getAttribute("href") === "#" + pageId) {
      link.classList.add("active");
    } else {
      link.classList.remove("active");
    }
  });

  const menu = document.getElementById("navMenu");
  if (menu && menu.classList.contains("open")) {
    menu.classList.remove("open");
  }

  window.scrollTo({ top: 0, behavior: "smooth" });
}

function toggleMobileMenu() {
  const menu = document.getElementById("navMenu");
  menu.classList.toggle("open");
}

function loadProducts() {
  const stored = localStorage.getItem("gulmira_flowers_products_v4");
  if (stored) {
    try {
      products = JSON.parse(stored);
    } catch (e) {
      products = [...DEFAULT_PRODUCTS];
    }
  } else {
    products = [...DEFAULT_PRODUCTS];
    saveProducts();
  }
}

function saveProducts() {
  try {
    localStorage.setItem("gulmira_flowers_products_v4", JSON.stringify(products));
    return true;
  } catch (err) {
    console.error("Ошибка сохранения в localStorage:", err);
    alert("Предупреждение: память браузера переполнена! Попробуйте сжать фото или использовать фото по ссылке.");
    return false;
  }
}

// Карточка товара с идеальным квадратным контейнером и фото во весь рост
function renderProductCard(p) {
  return `
    <div class="product-card">
      <div class="product-thumb">
        <span class="product-badge">${p.category}</span>
        <img src="${p.image}" alt="${p.title}" onerror="this.src='https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=600&q=80'">
      </div>
      <div class="product-body">
        <h3 class="product-title">${p.title}</h3>
        <p class="product-desc">${p.description || "Свежие растения высокого качества."}</p>
        <div class="product-footer">
          <div class="product-price">${Number(p.price).toLocaleString("ru-RU")} <span>₸</span></div>
          <button class="btn-add-cart" onclick="addToCart(${p.id})">В корзину 🛒</button>
        </div>
      </div>
    </div>
  `;
}

function renderAllViews() {
  const homeGrid = document.getElementById("homeProductsGrid");
  if (homeGrid) homeGrid.innerHTML = products.map(renderProductCard).join("");

  const allGrid = document.getElementById("allProductsGrid");
  if (allGrid) allGrid.innerHTML = products.map(renderProductCard).join("");

  const elkaGrid = document.getElementById("elkaGrid");
  if (elkaGrid) {
    const list = products.filter(p => p.category === "Ёлка");
    elkaGrid.innerHTML = list.length ? list.map(renderProductCard).join("") : "<p>В данной категории пока нет товаров.</p>";
  }

  const decGrid = document.getElementById("decorativeGrid");
  if (decGrid) {
    const list = products.filter(p => p.category === "Декоративные цветы");
    decGrid.innerHTML = list.length ? list.map(renderProductCard).join("") : "<p>В данной категории пока нет товаров.</p>";
  }

  const outGrid = document.getElementById("outdoorGrid");
  if (outGrid) {
    const list = products.filter(p => p.category === "Уличные цветы");
    outGrid.innerHTML = list.length ? list.map(renderProductCard).join("") : "<p>В данной категории пока нет товаров.</p>";
  }

  const fertGrid = document.getElementById("fertilizersGrid");
  if (fertGrid) {
    const list = products.filter(p => p.category === "Удобрение");
    fertGrid.innerHTML = list.length ? list.map(renderProductCard).join("") : "<p>В данной категории пока нет товаров.</p>";
  }

  renderAdminTable();
}

function filterHomeCatalog(category, btnElement) {
  const buttons = document.querySelectorAll("#page-home .filter-btn");
  buttons.forEach(b => b.classList.remove("active"));
  if (btnElement) btnElement.classList.add("active");

  const grid = document.getElementById("homeProductsGrid");
  if (!grid) return;

  if (category === "all") {
    grid.innerHTML = products.map(renderProductCard).join("");
  } else {
    const filtered = products.filter(p => p.category === category);
    grid.innerHTML = filtered.length ? filtered.map(renderProductCard).join("") : "<p>Товаров не найдено.</p>";
  }
}

function filterCatalog(category, btnElement) {
  const buttons = document.querySelectorAll("#page-catalog .filter-btn");
  buttons.forEach(b => b.classList.remove("active"));
  if (btnElement) btnElement.classList.add("active");

  const grid = document.getElementById("allProductsGrid");
  if (!grid) return;

  if (category === "all") {
    grid.innerHTML = products.map(renderProductCard).join("");
  } else {
    const filtered = products.filter(p => p.category === category);
    grid.innerHTML = filtered.length ? filtered.map(renderProductCard).join("") : "<p>Товаров не найдено.</p>";
  }
}

// КОРЗИНА
function loadCart() {
  const stored = localStorage.getItem("gulmira_cart_v4");
  if (stored) {
    try { cart = JSON.parse(stored); } catch (e) { cart = []; }
  }
  updateCartBadge();
}

function saveCart() {
  localStorage.setItem("gulmira_cart_v4", JSON.stringify(cart));
  updateCartBadge();
}

function updateCartBadge() {
  const countBadge = document.getElementById("cartCountBadge");
  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
  if (countBadge) countBadge.textContent = totalItems;
}

function addToCart(productId) {
  const prod = products.find(p => p.id === productId);
  if (!prod) return;

  const existing = cart.find(c => c.id === productId);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({
      id: prod.id,
      title: prod.title,
      price: prod.price,
      image: prod.image,
      category: prod.category,
      qty: 1
    });
  }

  saveCart();
  showToast(`«${prod.title}» добавлен в корзину!`);
}

function changeQty(productId, delta) {
  const item = cart.find(c => c.id === productId);
  if (!item) return;

  item.qty += delta;
  if (item.qty <= 0) {
    cart = cart.filter(c => c.id !== productId);
  }
  saveCart();
  renderCartModal();
}

function openCartModal() {
  renderCartModal();
  document.getElementById("cartModal").classList.add("active");
}

function closeCartModal() {
  document.getElementById("cartModal").classList.remove("active");
}

function renderCartModal() {
  const container = document.getElementById("cartItemsList");
  const totalElem = document.getElementById("cartTotalPrice");

  if (!container || !totalElem) return;

  if (cart.length === 0) {
    container.innerHTML = "<p style='text-align:center; padding: 25px 0; color:#64748b;'>Корзина пуста. Добавьте понравившиеся цветы или ёлки!</p>";
    totalElem.textContent = "0 ₸";
    return;
  }

  let total = 0;
  container.innerHTML = cart.map(item => {
    const itemTotal = item.price * item.qty;
    total += itemTotal;
    return `
      <div class="cart-item">
        <div class="cart-item-info">
          <img src="${item.image}" alt="${item.title}" class="cart-item-img">
          <div>
            <div class="cart-item-title">${item.title}</div>
            <div class="cart-item-price">${Number(item.price).toLocaleString("ru-RU")} ₸ × ${item.qty} шт.</div>
          </div>
        </div>
        <div class="cart-qty-ctrl">
          <button type="button" onclick="changeQty(${item.id}, -1)">−</button>
          <span>${item.qty}</span>
          <button type="button" onclick="changeQty(${item.id}, 1)">+</button>
        </div>
      </div>
    `;
  }).join("");

  totalElem.textContent = Number(total).toLocaleString("ru-RU") + " ₸";
}

// ПРЯМОЙ ПЕРЕХОД В WHATSAPP БЕЗ ЗАПОЛНЕНИЯ ПОЛЕЙ
function directOrderToWhatsApp() {
  if (cart.length === 0) {
    alert("Ваша корзина пуста! Выберите товары перед заказом.");
    return;
  }

  let totalSum = 0;
  let itemsText = "";

  cart.forEach((item, index) => {
    const sum = item.price * item.qty;
    totalSum += sum;
    itemsText += `${index + 1}. *${item.title}* (${item.category})
   Количество: ${item.qty} шт. × ${item.price.toLocaleString("ru-RU")} ₸ = *${sum.toLocaleString("ru-RU")} ₸*
`;
  });

  const message = 
    `🌸 *ЗАКАЗ ИЗ МАГАЗИНА «ГУЛМИРА ЦВЕТЫ»* 🌸

` +
    `Здравствуйте! Я хочу оформить заказ:

` +
    `📦 *Выбранные товары:*
${itemsText}
` +
    `💰 *ИТОГО К ОПЛАТЕ:* *${totalSum.toLocaleString("ru-RU")} ₸*

` +
    `Подскажите, пожалуйста, по наличию и доставке!`;

  const phoneTarget = "77085006666";
  const waUrl = `https://wa.me/${phoneTarget}?text=${encodeURIComponent(message)}`;

  cart = [];
  saveCart();
  closeCartModal();

  window.open(waUrl, "_blank");
}

// АДМИН-ПАНЕЛЬ
function loginAdmin() {
  const u = document.getElementById("adminUser").value.trim();
  const p = document.getElementById("adminPass").value.trim();

  if (u === SECRET_ADMIN_USER && p === SECRET_ADMIN_PASS) {
    isAdminLoggedIn = true;
    document.getElementById("adminLoginBlock").classList.add("d-none");
    document.getElementById("adminDashboardBlock").classList.remove("d-none");
    renderAdminTable();
  } else {
    alert("Доступ запрещен! Неверный логин или пароль.");
  }
}

function logoutAdmin() {
  isAdminLoggedIn = false;
  document.getElementById("adminLoginBlock").classList.remove("d-none");
  document.getElementById("adminDashboardBlock").classList.add("d-none");
  document.getElementById("adminPass").value = "";
  cancelEditProduct();
}

function togglePhotoSource() {
  const selected = document.querySelector('input[name="photoSource"]:checked').value;
  const urlBox = document.getElementById("urlInputContainer");
  const fileBox = document.getElementById("fileInputContainer");

  if (selected === "url") {
    urlBox.classList.remove("d-none");
    fileBox.classList.add("d-none");
    updateUrlPreview();
  } else {
    urlBox.classList.add("d-none");
    fileBox.classList.remove("d-none");
    if (uploadedImageDataUrl) {
      document.getElementById("adminPhotoPreview").src = uploadedImageDataUrl;
    }
  }
}

function updateUrlPreview() {
  const url = document.getElementById("prodImageUrl").value.trim();
  if (url) {
    document.getElementById("adminPhotoPreview").src = url;
  }
}

// УМНАЯ ОБРАБОТКА И СЖАТИЕ ФОТО ИЗ ГАЛЕРЕИ (Canvas Compressor)
// Это гарантирует, что фото любого размера сожмется до легкого формата и без проблем добавится!
function handleImageFileUpload(e) {
  const file = e.target.files[0];
  const statusElem = document.getElementById("fileUploadStatus");
  if (!file) return;

  statusElem.textContent = "⏳ Обработка и оптимизация фото...";

  const reader = new FileReader();
  reader.onload = function(event) {
    const img = new Image();
    img.onload = function() {
      // Сжимаем до максимальной стороны 700px, сохраняя весь рост и пропорции
      const maxSide = 700;
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxSide) {
          height = Math.round((height * maxSide) / width);
          width = maxSide;
        }
      } else {
        if (height > maxSide) {
          width = Math.round((width * maxSide) / height);
          height = maxSide;
        }
      }

      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);

      // Сохраняем оптимизированное JPEG превью (весит всего 40-70 КБ вместо 5 МБ)
      uploadedImageDataUrl = canvas.toDataURL("image/jpeg", 0.78);
      document.getElementById("adminPhotoPreview").src = uploadedImageDataUrl;
      statusElem.textContent = "✅ Фото успешно загружено и подготовлено в полный рост!";
    };
    img.src = event.target.result;
  };
  reader.readAsDataURL(file);
}

function saveAdminProduct() {
  const editId = document.getElementById("editProductId").value;
  const title = document.getElementById("prodTitle").value.trim();
  const category = document.getElementById("prodCategory").value;
  const priceVal = document.getElementById("prodPrice").value.trim();
  const price = parseFloat(priceVal);
  const desc = document.getElementById("prodDescription").value.trim();
  const photoType = document.querySelector('input[name="photoSource"]:checked').value;

  if (!title) {
    alert("Пожалуйста, введите название товара!");
    return;
  }
  if (!priceVal || isNaN(price) || price <= 0) {
    alert("Пожалуйста, укажите корректную цену в тенге!");
    return;
  }

  let finalImg = "";
  if (photoType === "url") {
    finalImg = document.getElementById("prodImageUrl").value.trim();
  } else {
    finalImg = uploadedImageDataUrl;
  }

  if (!finalImg) {
    // Если фото не выбрали, берем стандартное качественное фото
    finalImg = "https://images.unsplash.com/photo-1543257580-7269da773bf5?auto=format&fit=crop&w=600&q=80";
  }

  if (editId) {
    const idx = products.findIndex(p => p.id == editId);
    if (idx !== -1) {
      products[idx].title = title;
      products[idx].category = category;
      products[idx].price = price;
      products[idx].description = desc;
      if (finalImg) products[idx].image = finalImg;
    }
  } else {
    const newProduct = {
      id: Date.now(),
      title: title,
      category: category,
      price: price,
      image: finalImg,
      description: desc
    };
    products.unshift(newProduct);
  }

  const ok = saveProducts();
  if (ok) {
    renderAllViews();
    cancelEditProduct();
    alert("Товар успешно добавлен и доступен в каталоге!");
  }
}

function editProduct(id) {
  const p = products.find(prod => prod.id === id);
  if (!p) return;

  document.getElementById("editProductId").value = p.id;
  document.getElementById("prodTitle").value = p.title;
  document.getElementById("prodCategory").value = p.category;
  document.getElementById("prodPrice").value = p.price;
  document.getElementById("prodDescription").value = p.description || "";

  if (p.image && !p.image.startsWith("data:")) {
    document.querySelector('input[name="photoSource"][value="url"]').checked = true;
    document.getElementById("prodImageUrl").value = p.image;
    togglePhotoSource();
  } else {
    document.querySelector('input[name="photoSource"][value="file"]').checked = true;
    uploadedImageDataUrl = p.image;
    togglePhotoSource();
  }

  document.getElementById("adminPhotoPreview").src = p.image;
  document.getElementById("adminFormTitle").textContent = "✏️ Редактирование товара #" + p.id;
  document.getElementById("cancelEditBtn").style.display = "inline-block";

  window.scrollTo({ top: document.getElementById("adminDashboardBlock").offsetTop, behavior: "smooth" });
}

function cancelEditProduct() {
  document.getElementById("editProductId").value = "";
  document.getElementById("prodTitle").value = "";
  document.getElementById("prodPrice").value = "";
  document.getElementById("prodDescription").value = "";
  document.getElementById("prodImageUrl").value = "";
  document.getElementById("prodImageFile").value = "";
  document.getElementById("fileUploadStatus").textContent = "";
  uploadedImageDataUrl = "";
  document.getElementById("adminPhotoPreview").src = "https://images.unsplash.com/photo-1543257580-7269da773bf5?auto=format&fit=crop&w=600&q=80";

  document.getElementById("adminFormTitle").textContent = "➕ Добавить новый товар";
  document.getElementById("cancelEditBtn").style.display = "none";
}

function deleteProduct(id) {
  if (confirm("Вы уверены, что хотите удалить этот товар?")) {
    products = products.filter(p => p.id !== id);
    saveProducts();
    renderAllViews();
  }
}

function resetToInitialDefaults() {
  if (confirm("Сбросить все товары к начальному каталогу по умолчанию?")) {
    products = [...DEFAULT_PRODUCTS];
    saveProducts();
    renderAllViews();
  }
}

function renderAdminTable() {
  const tbody = document.getElementById("adminProductsTableBody");
  const countEl = document.getElementById("adminTotalCount");
  if (!tbody) return;

  if (countEl) countEl.textContent = products.length;

  tbody.innerHTML = products.map(p => `
    <tr>
      <td><img src="${p.image}" class="admin-prod-thumb" onerror="this.src='https://via.placeholder.com/50'"></td>
      <td><strong>${p.title}</strong></td>
      <td>${p.category}</td>
      <td>${Number(p.price).toLocaleString("ru-RU")} ₸</td>
      <td>
        <button class="btn-tbl-edit" onclick="editProduct(${p.id})">Редакт.</button>
        <button class="btn-tbl-delete" onclick="deleteProduct(${p.id})">Удалить</button>
      </td>
    </tr>
  `).join("");
}

function showToast(text) {
  const toast = document.createElement("div");
  toast.style.position = "fixed";
  toast.style.bottom = "20px";
  toast.style.right = "20px";
  toast.style.background = "#0d5c3a";
  toast.style.color = "#ffffff";
  toast.style.padding = "12px 20px";
  toast.style.borderRadius = "8px";
  toast.style.boxShadow = "0 6px 16px rgba(0,0,0,0.2)";
  toast.style.zIndex = "9999";
  toast.style.fontSize = "14px";
  toast.textContent = text;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 2600);
}
